package minesweeper;

public class minesweeper_functions {
	private int size; 
	public void Minesweeper() {
		size = 0;
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public void setSize(int dataSize) {
		size=dataSize;
	}
	public void generate_easy() {
		
		
	}
}
