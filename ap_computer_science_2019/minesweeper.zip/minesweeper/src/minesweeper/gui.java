package minesweeper;
import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.lang.Math.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import java.util.Scanner;
public class gui {
    public static void main(String args[]){
       Random r = new Random();
    	
    	
    	
    	//GENERATOR !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    	
    	JFrame frame = new JFrame("Minesweeper");
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setSize(500,500);
       String n = "";
       Scanner cInt = new Scanner(n);
       Scanner reader = new Scanner(System.in);
       System.out.print("Enter size of grid: ");
       final int SIZE = reader.nextInt();
       
     //MINE GENERATOR
       int j = 0;
       int mines = (SIZE * SIZE / 3);
       System.out.println(mines);
       boolean mineposition[][] = new boolean[SIZE+1][SIZE+1];
    	   while (j<mines) {
    		   int minex = r.nextInt(SIZE)+1;
    		   int miney = r.nextInt(SIZE)+1;
    		   if (mineposition[minex][miney]==false) {
    		   mineposition[minex][miney]= true;
    		   j++;
    		   
    		   System.out.println("set mine at: " + minex + ", " + miney);
    	   }}
       
       //DRAW MINES
       frame.setLayout(new GridLayout(SIZE,SIZE));
       JButton[][]buttons;
       buttons = new JButton[SIZE][SIZE];
       
       
       for (int i=0; i<SIZE; i++) {
    	   for (int k=0; k<SIZE; k++) {
    		   buttons[i][k] = new JButton((i+1)+"-"+(k+1));
    		   buttons[i][k].addActionListener(new ActionListener() { 
				@Override
				public void actionPerformed(ActionEvent e) {
				    int x = Integer.parseInt(e.getActionCommand().substring(0,1));
				    int y = Integer.parseInt(e.getActionCommand().substring(2,3));
				    System.out.println("Pressed (" + x + ", " + y + ")");
				    if (mineposition[x][y] == true) {
				    	System.out.println("bruh");
				    	buttons[x-1][y-1].setText("bruh");
				    	
				    } else {
				    	buttons[x-1][y-1].setText("");
				    }

				} 
    				} );
    		   frame.add(buttons[i][k]);
    		   frame.setVisible(true);
    	   }
       } 
     //Toggle
       frame.addKeyListener(new KeyListener() {
    	@Override   
    	public void keyPressed(KeyEvent e) {
    	    if (e.getKeyCode() == KeyEvent.VK_C && ((e.getModifiers() & KeyEvent.CTRL_MASK) != 0)) {
    	    	System.out.println("HAONASOASAOAFAF");
    	    }
    	    }

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
			
		}});
       frame.setVisible(true);
       
    	    
    	   
      
       
    	   
    }
}