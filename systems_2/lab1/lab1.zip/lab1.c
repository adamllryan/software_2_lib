#include <stdio.h>
int main() {
    printf("Hello. My name is XXX. \n");
}